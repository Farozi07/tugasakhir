<?php $__env->startSection('title', 'Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Transaksi</h1>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Produk</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td></td>
                                        <td>Rp<?php echo e(number_format($transaction['product']['price'], 0, ',', '.')); ?></td>
                                        <td>
                                            <?php if($transaction['status'] == 'pending'): ?>
                                                <span class="badge bg-warning text-dark"><?php echo e($transaction['status']); ?></span>
                                            <?php elseif($transaction['status'] == 'success'): ?>
                                                <span class="badge bg-success"><?php echo e($transaction['status']); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><?php echo e($transaction['status']); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($transaction['created_at']); ?></td>
                                        <td>
                                            <?php if($transaction['status'] == 'pending'): ?>
                                                <form action="<?php echo e(route('guest.checkout-process')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($transaction['id']); ?>">
                                                    <input type="hidden" name="product_id"
                                                        value="<?php echo e($transaction['product']['id']); ?>">
                                                    <input type="hidden" name="price"
                                                        value="<?php echo e($transaction['product']['price']); ?>">
                                                    <button type="submit" class="btn btn-primary">Bayar</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Tidak ada transaksi</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/guest/transaction.blade.php ENDPATH**/ ?>
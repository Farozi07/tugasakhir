<?php if(Auth::user()->role->name == 'employee'): ?>
    <li>
        <a href="">
            <i class="mdi mdi-view-dashboard-outline"></i>
            
            <span> Dashboard </span>
        </a>
    </li>
    <li>
        <a href="">
            <i class="fe-user-check"></i>
            
            <span> Pesanan </span>
        </a>
    </li>
    <li>
        <a href="">
            <i class="mdi mdi-account-alert-outline"></i>
            <?php echo $__env->yieldContent('notif.pemesan'); ?>
            <span> List Pemesan </span>
        </a>
    </li>
    <li>
        <a href="">
            <i class="fe-user-plus"></i>
            
            <span> Tambah Pemesan </span>
        </a>
    </li>
    <li>
        <a href="">
            <i class="fe-archive"></i>
            
            <span> Arsip Pemesan </span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tugasakhir\resources\views/layouts/sidebar/employee.blade.php ENDPATH**/ ?>
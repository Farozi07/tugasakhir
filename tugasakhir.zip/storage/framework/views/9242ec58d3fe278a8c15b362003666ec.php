<?php $__env->startSection('title', 'Daftar Permintaan Batal'); ?>
<?php $__env->startSection('pagetitle', 'Daftar Permintaan Batal'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <table id="responsive-datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Aula</th>
                        <th>Mulai</th>
                        <th>Berakhir</th>
                        <th>Alasan</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($p->user->name); ?></td>
                            <td><?php echo e($p->aula->nama); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->start)->format('d M Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->end)->format('d M Y')); ?></td>
                            <td><?php echo e($p->cancellation_reason); ?></td>
                            <td>
                                <form action="<?php echo e(route('admin.processCancellation', $p->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" name="action" value="approve"
                                        class="btn btn-success">Approve</button>
                                    <button type="submit" name="action" value="deny"
                                        class="btn btn-danger">Deny</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/admin/list_cancellation_requests.blade.php ENDPATH**/ ?>
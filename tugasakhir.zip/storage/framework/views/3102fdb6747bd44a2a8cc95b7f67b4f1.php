<?php $__env->startSection('title', 'Checkout Berhasil'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center">
        <div class="card">
            <div class="card-body text-center d-flex flex-column justify-content-center align-items-center">
                <h1 class="text-success">Pembayaran Berhasil</h1>
                <p class="text-success">Terima kasih telah melakukan pembayaran</p>
                <a href="<?php echo e(route('guest.list.booking')); ?>" class="btn btn-primary mt-3">Kembali ke Daftar Booking</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/guest/success.blade.php ENDPATH**/ ?>
<?php if(Auth::user()->role->name == 'admin'): ?>
    <li>
        <a href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="mdi mdi-view-dashboard-outline"></i>
            
            <span> Dashboard </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.list.booking')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> List Booking </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.list.booking.pending')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> List Booking Pending </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.list.booking.employee')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> List Kegiatan </span>
        </a>
    </li>
    <li>
    <li>
        <a href="<?php echo e(route('admin.list.booking.cancel.guest')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> List Permintaan Batal </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create.guest')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> Tambah Pemesan </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create.booking.guest')); ?>">
            <i class="fe-user-check"></i>
            
            <span> Tambah Booking </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create.booking.employee')); ?>">
            <i class="fe-user-check"></i>
            
            <span> Tambah Kegiatan </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.create.employee')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> Tambah Karyawan </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('admin.daftar.akun')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> List Akun </span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tugasakhir\resources\views/layouts/sidebar/admin.blade.php ENDPATH**/ ?>
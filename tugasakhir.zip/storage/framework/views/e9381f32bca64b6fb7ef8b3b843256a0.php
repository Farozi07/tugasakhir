<?php $__env->startSection('title', 'Detail'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('guest.dashboard')); ?>" class="btn btn-primary">Kembali</a>
            <div class="row mt-3">
                <div class="col-md-8">
                    <h1><?php echo e($product->id); ?></h1>
                    <h1><?php echo e($product->aula->nama); ?></h1>
                    <p><?php echo e($product->aula->deskripsi); ?></p>
                    
                    <form action="<?php echo e(route('guest.checkout-process')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="product_id" value="<?php echo e($product->end); ?>">
                        <input type="hidden" name="price" value="<?php echo e($product['price']); ?>">
                        <?php if(auth()->guard()->check()): ?>
                            <button type="submit" class="btn btn-primary">Beli Sekarang</button>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login untuk membeli</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/guest/product.blade.php ENDPATH**/ ?>
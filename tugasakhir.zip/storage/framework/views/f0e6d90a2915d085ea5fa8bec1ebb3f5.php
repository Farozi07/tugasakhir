<?php $__env->startSection('title', 'Daftar Pemesan'); ?>
<?php $__env->startSection('pagetitle', 'Daftar Pemesan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <table id="responsive-datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Status</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($p->user->guest->no_ktp); ?></td>
                            <td><?php echo e($p->user->name); ?></td>
                            <td><?php echo e($p->status); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#detail-<?php echo e($p->id); ?>">Detail</button>
                                <!-- Standard modal content -->
                                <div id="detail-<?php echo e($p->id); ?>" class="modal fade" tabindex="-1" role="dialog"
                                    aria-labelledby="standard-modalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title" id="standard-modalLabel">Detail Pemesan</h4>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><b>No KTP :</b> <?php echo e($p->user->guest->no_ktp); ?></p>
                                                <p><b>Nama :</b> <?php echo e($p->user->name); ?></p>
                                                <p><b>No Telp :</b> <?php echo e($p->user->guest->telp); ?></p>
                                                <p><b>Email :</b> <?php echo e($p->user->email); ?></p>
                                                <p><b>Alamat :</b> <?php echo e($p->user->guest->alamat); ?></p>
                                                <p><b>Mulai :</b> <?php echo e($p->start); ?></p>
                                                <p><b>Selesai :</b> <?php echo e($p->end); ?></p>
                                                <p><b>Keperluan :</b> <?php echo e($p->keperluan); ?></p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-light"
                                                    data-bs-dismiss="modal">Close</button>
                                                <button type="button" class="btn btn-success">Terima</button>
                                            </div>
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->


                                    <!-- Bootstrap 4 requires Popper.js and Bootstrap.js -->
                                    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>
                                    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
                                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/admin/list_booking_guest.blade.php ENDPATH**/ ?>
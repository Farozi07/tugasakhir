<div>
    <div id='calendar'></div>
</div>

<?php $__env->startPush('styles'); ?>
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.min.css' rel='stylesheet' />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.min.js'></script>
    <script>
        document.addEventListener('livewire:load', function() {
            var Calendar = FullCalendar.Calendar;
            var calendarEl = document.getElementById('calendar');

            var calendar = new Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                events: <?php echo json_encode($events, 15, 512) ?>
            });

            calendar.render();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\tugasakhir\resources\views/livewire/calendar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Daftar Booking'); ?>
<?php $__env->startSection('pagetitle', 'Daftar Booking'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <table id="responsive-datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Aula</th>
                        <th>Mulai</th>
                        <th>Berakhir</th>
                        <th>Keperluan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($p->user->name); ?></th>
                            <td><?php echo e($p->aula->nama); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->start)->format('d-m-Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->end)->format('d-m-Y')); ?></td>
                            <td><?php echo e($p->keperluan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/admin/list_booking.blade.php ENDPATH**/ ?>
<?php if(Auth::user()->role->name == 'guest'): ?>
    <li>
        <a href="<?php echo e(route('guest.dashboard')); ?>">
            <i class="mdi mdi-view-dashboard-outline"></i>
            
            <span> Dashboard </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('guest.fillData')); ?>">
            <i class="fe-user-plus"></i>
            
            <span> Edit Profil </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('guest.list.booking')); ?>">
            <i class="fe-user-check"></i>
            
            <span> List Pesanan </span>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('guest.create.booking')); ?>">
            <i class="mdi mdi-account-alert-outline"></i>
            <span> Buat Pesanan </span>
        </a>
    </li>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tugasakhir\resources\views/layouts/sidebar/guest.blade.php ENDPATH**/ ?>
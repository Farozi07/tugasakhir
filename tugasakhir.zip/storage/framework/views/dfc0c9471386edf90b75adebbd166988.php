<?php $__env->startSection('title', 'Daftar Kegiatan'); ?>
<?php $__env->startSection('pagetitle', 'Daftar Kegiatan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <table id="responsive-datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Aula</th>
                        <th>Bidang</th>
                        <th>Mulai</th>
                        <th>Berakhir</th>
                        <th>Kegiatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->user->name); ?></td>
                            <td><?php echo e($p->aula->nama); ?></td>
                            <td><?php echo e($p->user->employee->nama_bidang); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->start)->format('d-m-Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($p->end)->format('d-m-Y')); ?></td>
                            <td><?php echo e($p->keperluan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\tugasakhir\resources\views/admin/list_booking_employee.blade.php ENDPATH**/ ?>
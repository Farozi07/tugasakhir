<!--- Sidemenu -->
<div id="sidebar-menu">
    <ul id="side-menu">
        <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.sidebar.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.sidebar.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
</div>
<!-- End Sidebar -->
<?php /**PATH C:\laragon\www\tugasakhir\resources\views/layouts/sidebar/sidebar.blade.php ENDPATH**/ ?>
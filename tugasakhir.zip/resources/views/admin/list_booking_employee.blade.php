@extends('layouts.app')
@section('title', 'Daftar Kegiatan')
@section('pagetitle', 'Daftar Kegiatan')
@section('content')
    <div class="row">
        <div class="col-12">
            <table id="responsive-datatable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Aula</th>
                        <th>Bidang</th>
                        <th>Mulai</th>
                        <th>Berakhir</th>
                        <th>Kegiatan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($data as $p)
                        <tr>
                            <td>{{ $p->user->name }}</td>
                            <td>{{ $p->aula->nama }}</td>
                            <td>{{ $p->user->employee->nama_bidang }}</td>
                            <td>{{ \Carbon\Carbon::parse($p->start)->format('d-m-Y') }}</td>
                            <td>{{ \Carbon\Carbon::parse($p->end)->format('d-m-Y') }}</td>
                            <td>{{ $p->keperluan }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

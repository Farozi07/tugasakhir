<!--- Sidemenu -->
<div id="sidebar-menu">
    <ul id="side-menu">
        @include('layouts.sidebar.admin')
        @include('layouts.sidebar.employee')
        @include('layouts.sidebar.guest')
    </ul>
</div>
<!-- End Sidebar -->
